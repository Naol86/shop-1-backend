import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// Export the Prisma client instance
export default prisma;
